plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.personalprofilepage"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.personalprofilepage"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
<<<<<<< HEAD
=======

>>>>>>> origin/master
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
<<<<<<< HEAD

=======
>>>>>>> origin/master
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
<<<<<<< HEAD

=======
>>>>>>> origin/master
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
<<<<<<< HEAD
    implementation("androidx.core:core-ktx:1.12.0") // Update to the latest version
    implementation("androidx.appcompat:appcompat:1.6.1") // Update to the latest version
    implementation("com.google.android.material:material:1.10.0") // Update to the latest version
    implementation("androidx.activity:activity-ktx:1.7.2") // Update to the latest version
    implementation("androidx.constraintlayout:constraintlayout:2.1.4") // Update to the latest version
    testImplementation("junit:junit:4.13.2") // Update to the latest version
    androidTestImplementation("androidx.test.ext:junit:1.1.5") // Update to the latest version
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1") // Update to the latest version
}
=======

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}
>>>>>>> origin/master
