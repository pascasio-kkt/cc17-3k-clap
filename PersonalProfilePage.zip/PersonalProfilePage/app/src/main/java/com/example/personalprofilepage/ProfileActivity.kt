package com.example.personalprofilepage

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etAddress: EditText
    private lateinit var etContact: EditText
    private lateinit var btnSaveProfile: Button
    private lateinit var tvFeedback: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etAddress = findViewById(R.id.etAddress)
        etContact = findViewById(R.id.etContact)
        btnSaveProfile = findViewById(R.id.btnSaveProfile)
        tvFeedback = findViewById(R.id.tvFeedback)

        // Populate fields with data from intent
        intent.extras?.let { bundle ->
            etName.setText(bundle.getString("name", ""))
            etEmail.setText(bundle.getString("email", ""))
            etAddress.setText(bundle.getString("address", ""))
            etContact.setText(bundle.getString("contact", ""))
        }

        btnSaveProfile.setOnClickListener {
            if (validateInputs()) {
                // Here you would typically save the profile data
                // For this example, we'll just show a success message
                showFeedback("Profile saved successfully")
            } else {
                showFeedback()
            }
        }
    }

    private fun validateInputs(): Boolean {
        return etName.text.isNotEmpty() &&
                etEmail.text.isNotEmpty() &&
                etAddress.text.isNotEmpty() &&
                etContact.text.isNotEmpty()
    }

    private fun showFeedback(message: String = "Please fill all fields") {
        tvFeedback.text = message
        tvFeedback.visibility = View.VISIBLE
    }
}